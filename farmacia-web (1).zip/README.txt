📦 Farmacia Web - Proyecto Base

Pasos para iniciar:
1. Asegurate de tener Node.js instalado.
2. Ejecutá en terminal:
   npm install
   npm run dev
3. Abrí http://localhost:3000 en tu navegador.

Incluye estructura básica con catálogo, contacto, y componentes UI personalizados.
